from django.apps import AppConfig


class GestionRéservationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gestion_réservation'
