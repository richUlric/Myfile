<?php
// Configuration de la base de données MySQL
$servername = "localhost";
$username = "nom_utilisateur";
$password = "mot_de_passe";
$dbname = "nom_base_de_données";
?>
